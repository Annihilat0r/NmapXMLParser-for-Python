# outer __init__.py

from jp_test import *
from nmap_diff import *